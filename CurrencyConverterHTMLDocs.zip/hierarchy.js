var hierarchy =
[
    [ "ApiController", null, [
      [ "CurrencyInfo.Controllers.CurrencyExchangeController", "class_currency_info_1_1_controllers_1_1_currency_exchange_controller.html", null ]
    ] ],
    [ "Controller", null, [
      [ "CurrencyConverter.Controllers.HomeController", "class_currency_converter_1_1_controllers_1_1_home_controller.html", null ]
    ] ],
    [ "CurrencyInfo.Models.Conversion", "class_currency_info_1_1_models_1_1_conversion.html", null ],
    [ "CurrencyConverter.Models.CountryExchangeInfo", "class_currency_converter_1_1_models_1_1_country_exchange_info.html", null ],
    [ "CurrencyInfo.Models.Currency", "class_currency_info_1_1_models_1_1_currency.html", null ],
    [ "DbContext", null, [
      [ "CurrencyInfo.Models.CurrencyEntitiesContext", "class_currency_info_1_1_models_1_1_currency_entities_context.html", null ]
    ] ],
    [ "CurrencyConverter.FilterConfig", "class_currency_converter_1_1_filter_config.html", null ],
    [ "HttpApplication", null, [
      [ "CurrencyConverter.MvcApplication", "class_currency_converter_1_1_mvc_application.html", null ],
      [ "CurrencyInfo.WebApiApplication", "class_currency_info_1_1_web_api_application.html", null ]
    ] ],
    [ "CurrencyInfo.ICurrency", "class_currency_info_1_1_i_currency.html", null ],
    [ "CurrencyConverter.RouteConfig", "class_currency_converter_1_1_route_config.html", null ],
    [ "CurrencyInfo.Models.tbCurrency", "class_currency_info_1_1_models_1_1tb_currency.html", null ],
    [ "CurrencyInfo.Tests.UnitTest1", "class_currency_info_1_1_tests_1_1_unit_test1.html", null ],
    [ "CurrencyInfo.Models.vwExchangeRate", "class_currency_info_1_1_models_1_1vw_exchange_rate.html", null ],
    [ "CurrencyConverter.Models.WorldCurrencies", "class_currency_converter_1_1_models_1_1_world_currencies.html", null ]
];