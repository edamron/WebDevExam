var class_currency_info_1_1_models_1_1vw_exchange_rate =
[
    [ "Code", "class_currency_info_1_1_models_1_1vw_exchange_rate.html#ab2534146732b700256ab10414c34cd87", null ],
    [ "Description", "class_currency_info_1_1_models_1_1vw_exchange_rate.html#a30532fbc093b340f9594821cd04977ab", null ],
    [ "ExchangeRate", "class_currency_info_1_1_models_1_1vw_exchange_rate.html#adc8d1115c9439a20ee8aad16f3c5c3a1", null ]
];