var class_currency_info_1_1_models_1_1tb_currency =
[
    [ "Code", "class_currency_info_1_1_models_1_1tb_currency.html#a4ff9f4fddfb542175c9f1813c2375c55", null ],
    [ "Description", "class_currency_info_1_1_models_1_1tb_currency.html#acd551de6d8a46dcbd1253911af1f28bc", null ],
    [ "ID", "class_currency_info_1_1_models_1_1tb_currency.html#aa62f6a80797e6c157538af9868357ebe", null ]
];