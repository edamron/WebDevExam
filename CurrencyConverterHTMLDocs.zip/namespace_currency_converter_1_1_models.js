var namespace_currency_converter_1_1_models =
[
    [ "CountryExchangeInfo", "class_currency_converter_1_1_models_1_1_country_exchange_info.html", "class_currency_converter_1_1_models_1_1_country_exchange_info" ],
    [ "WorldCurrencies", "class_currency_converter_1_1_models_1_1_world_currencies.html", "class_currency_converter_1_1_models_1_1_world_currencies" ]
];