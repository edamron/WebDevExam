var namespaces =
[
    [ "CurrencyConverter", "namespace_currency_converter.html", "namespace_currency_converter" ],
    [ "CurrencyInfo", "namespace_currency_info.html", "namespace_currency_info" ]
];