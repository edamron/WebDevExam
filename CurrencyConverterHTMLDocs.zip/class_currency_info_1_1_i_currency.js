var class_currency_info_1_1_i_currency =
[
    [ "Code", "class_currency_info_1_1_i_currency.html#a67484d508091baef5ca022b6cad1e79c", null ],
    [ "Description", "class_currency_info_1_1_i_currency.html#a78dbac79add72a8854c703baadd3c2cf", null ],
    [ "ExchangeRate", "class_currency_info_1_1_i_currency.html#a134d234d87c7eb9fbe7c2d2e59183e3c", null ]
];