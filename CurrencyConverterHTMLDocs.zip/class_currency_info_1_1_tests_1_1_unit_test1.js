var class_currency_info_1_1_tests_1_1_unit_test1 =
[
    [ "USD_Available", "class_currency_info_1_1_tests_1_1_unit_test1.html#afe4b3ff29ae2a00c9688244d0f01b7c0", null ]
];