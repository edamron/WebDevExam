var class_currency_info_1_1_models_1_1_conversion =
[
    [ "ConversionAmount", "class_currency_info_1_1_models_1_1_conversion.html#a7b14589f3d6ed5a3dc57d34a779e40f8", null ],
    [ "Source", "class_currency_info_1_1_models_1_1_conversion.html#afdc8bb8ad3829cf36c4aff1d79ec4116", null ],
    [ "Target", "class_currency_info_1_1_models_1_1_conversion.html#aed557d3b1d21a52b4a503fe31dbdf6cb", null ]
];