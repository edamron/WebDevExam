var class_currency_converter_1_1_models_1_1_country_exchange_info =
[
    [ "Code", "class_currency_converter_1_1_models_1_1_country_exchange_info.html#a07914fa16f09bfb0343b9008e96a7d33", null ],
    [ "CountryAndCurrency", "class_currency_converter_1_1_models_1_1_country_exchange_info.html#a64106661335ca8646624e98a3d440978", null ],
    [ "ExchangeRate", "class_currency_converter_1_1_models_1_1_country_exchange_info.html#a6071faf123a293238228df9d98b0dd64", null ]
];