var class_currency_info_1_1_models_1_1_currency =
[
    [ "Code", "class_currency_info_1_1_models_1_1_currency.html#a201ee9f7779e19a59e2a85953602d364", null ],
    [ "CountryAndCurrency", "class_currency_info_1_1_models_1_1_currency.html#ab335dba4d1faec39a8f8ee0a2ce45200", null ],
    [ "ExchangeRate", "class_currency_info_1_1_models_1_1_currency.html#a07fa8ae85b40c31fa7e2d13a99288224", null ]
];